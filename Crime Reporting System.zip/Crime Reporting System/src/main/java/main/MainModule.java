package main;

import entity.Cases;
import entity.Incidents;
import exception.IncidentNumberNotFoundException;

import java.util.Date;
import java.util.InputMismatchException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import dao.ICrimeAnalysisService;
import dao.ICrimeAnalysisServiceImpl;

@SuppressWarnings("unused")
public class MainModule {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    static ICrimeAnalysisService icrimeanalysisService = new ICrimeAnalysisServiceImpl();
    private static java.sql.Date Date;
    private static java.sql.Date startingDate;
    private static java.sql.Date endingDate;
    private static int numIncidents;

    @SuppressWarnings({ "unchecked" })
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("******** Main Menu ********");
            System.out.println("1. Create Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. Get Incidents in Date Range");
            System.out.println("4. Search Incidents");
            System.out.println("5. Generate Incident Report");
            System.out.println("6. Create New Case");
            System.out.println("7.Get Case Details");
            System.out.println("8. Update Case Details");
            System.out.println("9. Get All Cases");
            System.out.println("10. Exit");


            System.out.print("Enter your choice: ");
            int choice = readInt(scanner);

            switch (choice) {
                case 1: // Create Incident
                    Incidents newIncident = new Incidents();
                    System.out.print("Enter Incident ID: ");
                    newIncident.setIncidentID(scanner.nextInt());
                    System.out.print("Enter Incident Type: ");
                    newIncident.setIncidentType(scanner.next());
                    System.out.print("Enter Incident Date (yyyy-MM-dd): ");
                    String incidentDateStr = scanner.next();
                    try {
                        Date incidentDate = dateFormat.parse(incidentDateStr);
                        java.sql.Date sqlIncidentDate = new java.sql.Date(incidentDate.getTime());
                        newIncident.setIncidentDate(sqlIncidentDate);
                    } catch (ParseException e) {
                        System.out.println("Invalid date format. Please use yyyy-MM-dd.");
                        break;
                    }
                    System.out.print("Enter Latitude: ");
                    double latitude = scanner.nextDouble();
                    newIncident.setLatitude(latitude);
                    System.out.print("Enter Longitude: ");
                    double longitude = scanner.nextDouble();
                    newIncident.setLongitude(longitude);
                    System.out.print("Enter Description: ");
                    scanner.nextLine(); // Consume newline left by nextDouble()
                    newIncident.setIncidentDescription(scanner.nextLine());
                    System.out.print("Enter Status: ");
                    newIncident.setIncidentStatus(scanner.nextLine());
                    System.out.print("Enter Agency ID: ");
                    newIncident.setAgencyID(scanner.nextInt());
                    System.out.print("Enter Victim ID: ");
                    newIncident.setVictimID(scanner.nextInt());
                    System.out.print("Enter Suspect ID: ");
                    newIncident.setSuspectID(scanner.nextInt());
                    boolean incidentCreated = icrimeanalysisService.createIncident(newIncident);
                    if (incidentCreated) {
                        System.out.println("Incident created successfully.");
                    } else {
                        System.out.println("Failed to create incident.");
                    }
                    break;


                case 2:// Update Incident Status
                    try {
                        System.out.print("Enter Incident ID for status update: ");
                        int incidentIdForUpdate = scanner.nextInt();
                        System.out.print("Enter new status: ");
                        String newStatus = scanner.next();
                        boolean statusUpdated = icrimeanalysisService.updateIncidentStatus(incidentIdForUpdate, newStatus);
                        if (statusUpdated) {
                            System.out.println("Incident status updated successfully.");
                        } else {
                            throw new IncidentNumberNotFoundException();
                        }
                    } catch (IncidentNumberNotFoundException e) {
                        System.out.println(e);
                    }
                    break;
                case 3:
                    System.out.print("Enter start date (yyyy-MM-dd): ");
                    String startDateString = scanner.next();
                    System.out.print("Enter end date (yyyy-MM-dd): ");
                    String endDateString = scanner.next();
                    try {
                        ICrimeAnalysisService crimeAnalysisService = new ICrimeAnalysisServiceImpl();
                        // Retrieve incidents in the date range
                        Collection<Incidents> incidentsList = crimeAnalysisService.getIncidentsInDateRange(startDateString, endDateString);

                        if (incidentsList.isEmpty()) {
                            System.out.println("No incidents found within the specified date range.");
                        } else {
                            System.out.println("Incidents within the date range:");
                            for (Incidents incident : incidentsList) {
                                System.out.println("Incident ID: " + incident.getIncidentID());
                                System.out.println("Type: " + incident.getIncidentType());
                                System.out.println("Date: " + incident.getIncidentDate());
                                System.out.println("Description: " + incident.getIncidentDescription());
                                System.out.println("Status: " + incident.getIncidentStatus());
                                System.out.println("Victim ID: " + incident.getVictimID());
                                System.out.println("-----------------------------------");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4: // Search Incidents
                    // Search Incidents by type
                    System.out.print("Enter Incident Type to Search: ");
                    String incidentType = scanner.next();
                    Incidents criteria = new Incidents();
                    criteria.setIncidentType(incidentType);
                    Collection<Incidents> incidentsList = icrimeanalysisService.searchIncidents(criteria);
                    if (incidentsList.isEmpty()) {
                        System.out.println("No incidents found for the specified type.");
                    } else {
                        System.out.println("Incidents with the specified type:");
                        for (Incidents incident : incidentsList) {
                            System.out.println("Incident ID: " + incident.getIncidentID());
                            System.out.println("Incident Type: " + incident.getIncidentType());
                            System.out.println("Incident Date: " + incident.getIncidentDate());
                            System.out.println("Incident Description: " + incident.getIncidentDescription());
                            System.out.println("Incident Status: " + incident.getIncidentStatus());
                            System.out.println();
                        }
                    }
                    break;

                case 5:
                    System.out.print("Enter Incident ID: ");
                    int incidentIdForReport = scanner.nextInt();

                    // Retrieve incident details based on the provided Incident ID
                    Incidents incidentForReport = icrimeanalysisService.getIncidentById(incidentIdForReport);

                    if (incidentForReport != null) {
                        // Display incident details
                        System.out.println("Incident Details:");
                        System.out.println("Incident ID: " + incidentForReport.getIncidentID());
                        System.out.println("Type: " + incidentForReport.getIncidentType());
                        System.out.println("Date: " + incidentForReport.getIncidentDate());
                        // Print other incident details as needed

                        // Ask for reporting officer ID
                        System.out.print("Enter Reporting Officer ID: ");
                        int reportingOfficerId = scanner.nextInt();
                        scanner.nextLine();

                        // Generate Incident Report
                        Object generatedReport = icrimeanalysisService.generateIncidentReport(incidentForReport, reportingOfficerId);

                        // Print or process the generatedReport as needed
                        if (generatedReport != null) {
                            Map<String, Object> reportDetails = (Map<String, Object>) generatedReport;
                            System.out.println("Incident Report Generated Successfully. Report Details:");
                            System.out.println("Report ID: " + reportDetails.get("reportID"));
                            System.out.println("Report Date: " + reportDetails.get("reportDate"));
                            System.out.println("Status: " + reportDetails.get("Reportstatus"));
                            System.out.println("Report Details:\n" + reportDetails.get("reportDetails"));
                        } else {
                            System.out.println("Failed to generate incident report. Please check the input details.");
                        }
                    } else {
                        System.out.println("Incident not found for the specified Incident ID.");
                    }
                    break;
                case 6:
                    System.out.print("Enter Case Description: ");
                    scanner.nextLine(); // consume the newline character
                    String caseDescription = scanner.nextLine();

                    System.out.print("Enter number of Incidents associated with this case: ");
                    int numberOfIncidents = scanner.nextInt();

                    // Create a collection to hold associated incidents
                    Collection<Incidents> associatedIncidents = new ArrayList<>();

                    for (int i = 0; i < numberOfIncidents; i++) {
                        System.out.print("Enter Incident ID for incident " + (i + 1) + ": ");
                        int incidentId = scanner.nextInt();

                        // Retrieve incident details based on incident ID
                        Incidents incident = icrimeanalysisService.getIncidentById(incidentId);

                        if (incident != null) {
                            // Add the incident to the collection
                            associatedIncidents.add(incident);
                        } else {
                            System.out.println("Incident not found for the specified ID: " + incidentId);
                            // Reset the loop index to re-enter the incident ID
                            i--;
                        }
                    }

                    // Create the case using the service method
                    Cases newCase = icrimeanalysisService.createCase(caseDescription, associatedIncidents);
                    System.out.println("New Case created with ID: " + newCase.getCaseId());
                    System.out.println("Associated Incidents:");
                    for (Incidents incident : associatedIncidents) {
                        System.out.println("- Incident ID: " + incident.getIncidentID());
                    }

                    if (newCase != null) {
                        System.out.println("New Case created with ID: " + newCase.getCaseId());
                    } else {
                        System.out.println("Failed to create the case.");
                    }
                    break;

                case 7: // Get Case Details
                    System.out.print("Enter Case ID: ");
                    int caseId = scanner.nextInt();
                    Cases caseDetails = icrimeanalysisService.getCaseDetails(caseId);
                    if (caseDetails != null) {
                        System.out.println("Case Details:");
                        System.out.println("Case ID: " + caseDetails.getCaseId());
                        System.out.println("Case Description: " + caseDetails.getCaseDescription());
                        System.out.println("Associated Incidents:");
                        for (Incidents incident : caseDetails.getAssociatedIncidents()) {
                            System.out.println("- Incident ID: " + incident.getIncidentID());
                            System.out.println("- Incident ID: " + incident.getIncidentID());
                            System.out.println("  Type: " + incident.getIncidentType());
                            System.out.println("  Date: " + incident.getIncidentDate());
                            System.out.println("  Description: " + incident.getIncidentDescription());
                            System.out.println("  Status: " + incident.getIncidentStatus());
                            System.out.println("  Agency ID: " + incident.getAgencyID());
                            System.out.println("  Victim ID: " + incident.getVictimID());
                            System.out.println("  Suspect ID: " + incident.getSuspectID());
                            System.out.println("  Location: " + incident.getLatitude() + ", " + incident.getLongitude());
                        }
                    } else {
                        System.out.println("Case not found for the specified Case ID.");
                    }
                    break;
                case 8: // Update Case Details
                    System.out.print("Enter Case ID for update: ");
                    int caseIdForUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new Case Description: ");
                    String newCaseDescription = scanner.nextLine();
                    Cases caseObj = new Cases();
                    caseObj.setCaseId(caseIdForUpdate);
                    caseObj.setCaseDescription(newCaseDescription);
                    boolean caseUpdated = icrimeanalysisService.updateCaseDetails(caseObj);
                    if (caseUpdated) {
                        System.out.println("Case details updated successfully.");
                    } else {
                        System.out.println("Failed to update case details.");
                    }
                    break;
                case 9: // Get All Cases
                    List<Cases> allCases = icrimeanalysisService.getAllCases();
                    if (allCases.isEmpty()) {
                        System.out.println("No cases found.");
                    } else {
                        System.out.println("All Cases:");
                        for (Cases eachCase : allCases) {
                            System.out.println("Case ID: " + eachCase.getCaseId());
                            System.out.println("Case Description: " + eachCase.getCaseDescription());
                            System.out.println("Associated Incidents:");
                            for (Incidents incident : eachCase.getAssociatedIncidents()) {
                                System.out.println("- Incident ID: " + incident.getIncidentID());
                                System.out.println("Type: " + incident.getIncidentType());
                                System.out.println("Date: " + incident.getIncidentDate());
                                System.out.println("Description: " + incident.getIncidentDescription());
                                System.out.println("Status: " + incident.getIncidentStatus());
                                System.out.println("Agency ID: " + incident.getAgencyID());
                                System.out.println("Victim ID: " + incident.getVictimID());
                                System.out.println("Suspect ID: " + incident.getSuspectID());
                                System.out.println("Location: " + incident.getLatitude() + ", " + incident.getLongitude());
                            }
                            System.out.println("-----------------------------------");
                        }
                    }
                    break;

                case 10: // Exit
                    System.out.println("Exiting the program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 8.");
            }
        }
    }

    private static String getId() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getId'");
    }

    private static int readInt(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.print("Invalid input. Please enter a number: ");
            scanner.next();
        }
        return scanner.nextInt();
    }
}


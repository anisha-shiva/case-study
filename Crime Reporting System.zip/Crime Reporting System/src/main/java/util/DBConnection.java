package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.Properties;

public class DBConnection {
    private static Connection connection;

    public static Connection getConnection(String string) throws SQLException {
        if (connection == null || connection.isClosed()) {
            Properties properties = PropertyUtil.loadProperties("C:\\Users\\ASUS\\IdeaProjects\\CrimeReportingSystem\\src\\main\\db.properties");
            String connectionString = PropertyUtil.getConnectionString(properties);
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Load the JDBC driver for MySQL
                connection = DriverManager.getConnection(connectionString);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new SQLException("Failed to load JDBC driver");
            }
        }
        return connection;
    }
}



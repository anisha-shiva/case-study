package dao;

import static org.junit.Assert.*;

import dao.ICrimeAnalysisServiceImpl;
import entity.Incidents;
import exception.IncidentNumberNotFoundException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Date;
import java.time.LocalDate;

public class ICrimeAnalysisServiceImplTest {

    private ICrimeAnalysisServiceImpl crimeAnalysisService;

    @Before
    public void setUp() {
        // Initialize the ICrimeAnalysisServiceImpl instance before each test
        crimeAnalysisService = new ICrimeAnalysisServiceImpl();
    }

    @After
    public void tearDown() {
        // Clean up any resources after each test (if needed)
    }

    @Test
    public void testCreateIncident_Successful() {
        // Create a sample incident for testing
        Incidents incident = new Incidents();
        incident.setIncidentID(6);
        incident.setIncidentType("Theft");
        incident.setIncidentDescription("Gold missing");
        incident.setIncidentStatus("Open");
        incident.setAgencyID(1);
        incident.setVictimID(2);
        incident.setSuspectID(3);
        incident.setLatitude(40.712);
        incident.setLongitude(74.006);

        // Set a specific incident date
        incident.setIncidentDate(Date.valueOf(LocalDate.of(2024, 01, 10)));

        // Call the createIncident method and assert that it returns true (indicating success)
        assertTrue(crimeAnalysisService.createIncident(incident));
    }
    @Test
    public void testUpdateIncidentStatus_Successful() throws IncidentNumberNotFoundException {
        // Set up a test incident ID and status
        int incidentId = 1;
        String newStatus = "Closed";

        // Call the updateIncidentStatus method and assert that it returns true (indicating success)
        assertTrue(crimeAnalysisService.updateIncidentStatus(incidentId, newStatus));
    }

    @Test(expected = IncidentNumberNotFoundException.class)
    public void testUpdateIncidentStatus_IncorrectIncidentId() throws IncidentNumberNotFoundException {
        // Set up a non-existent incident ID
        int nonExistentIncidentId = 1000;
        String newStatus = "Closed";

        // Call the updateIncidentStatus method with a non-existent incident ID
        // This should throw an IncidentNumberNotFoundException
        crimeAnalysisService.updateIncidentStatus(nonExistentIncidentId, newStatus);
    }
}